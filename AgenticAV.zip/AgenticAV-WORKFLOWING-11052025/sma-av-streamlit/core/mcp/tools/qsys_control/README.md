# Q-SYS Control MCP Connector

Provides a template for sending commands to Q-SYS Core processors or control plugins.

Implement the stubs in `connector.py` using Q-SYS control APIs or the QRC protocol to adjust routing, gain, or recall snapshots.
