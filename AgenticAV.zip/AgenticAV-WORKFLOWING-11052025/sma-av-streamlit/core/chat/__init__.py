# core/chat/__init__.py
"""Chat services and helpers (threads & messages)."""
