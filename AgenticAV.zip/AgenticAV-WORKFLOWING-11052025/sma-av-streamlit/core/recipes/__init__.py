# core/recipes/__init__.py
"""Recipes utilities: save/load YAML, attach to agents, validators, compilers."""
__all__ = ["service", "attach"]
