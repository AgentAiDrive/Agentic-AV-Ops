# __init__.py for fixed agents package
# This package holds fixed system agents: Intake, Plan, Act, Verify, Learn, Baseline
from .registry import FIXED_AGENT_REGISTRY
